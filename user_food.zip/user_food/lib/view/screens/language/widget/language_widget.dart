import 'package:apex_mart/controller/localization_controller.dart';
import 'package:apex_mart/data/model/response/language_model.dart';
import 'package:apex_mart/util/app_constants.dart';
import 'package:apex_mart/util/dimensions.dart';
import 'package:apex_mart/util/styles.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';


class LanguageWidget extends StatelessWidget {
  final LanguageModel languageModel;
  final LocalizationController localizationController;
  final int index;
  LanguageWidget({@required this.languageModel, @required this.localizationController, @required this.index});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        localizationController.setLanguage(Locale(
          AppConstants.languages[index].languageCode,
          AppConstants.languages[index].countryCode,
        ));
        localizationController.setSelectIndex(index);
      },
      child: Card(
        elevation: 2,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(Dimensions.RADIUS_ClayContainer_r)
        ),
        child: Stack(children: [

          Center(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              CircleAvatar(
                radius:40,
                backgroundColor: Colors.orange.shade50,
                child: Image.asset(
                  languageModel.imageUrl, width: 36, height: 36,
                  color: languageModel.languageCode == 'en' || languageModel.languageCode == 'ar'
                      ? Theme.of(context).textTheme.bodyText1.color : null,
                ),
              ),
              SizedBox(height: Dimensions.PADDING_SIZE_LARGE),
              Text(languageModel.languageName, style: poppinsRegular,),
            ]),
          ),

          localizationController.selectedIndex == index ? Positioned(
            top: 0, right: 0,
            child: Icon(Icons.check_circle, color: Theme.of(context).primaryColor, size: 25),
          ) : SizedBox(),

        ]),
      ),
    );
  }
}
