import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:apex_mart/controller/splash_controller.dart';
import 'package:apex_mart/helper/responsive_helper.dart';
import 'package:apex_mart/util/dimensions.dart';
import 'package:apex_mart/view/base/cart_widget.dart';
import 'package:apex_mart/view/screens/cart/cart_screen.dart';
import 'package:apex_mart/view/screens/dashboard/widget/bottom_nav_item.dart';
import 'package:apex_mart/view/screens/favourite/favourite_screen.dart';
import 'package:apex_mart/view/screens/home/home_screen.dart';
import 'package:apex_mart/view/screens/menu/menu_screen.dart';
import 'package:apex_mart/view/screens/order/order_screen.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:persistent_bottom_nav_bar/persistent_tab_view.dart';

class DashboardScreen extends StatefulWidget {
  final int pageIndex;
  DashboardScreen({@required this.pageIndex});

  @override
  _DashboardScreenState createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  PageController _pageController;
  int _pageIndex = 0;
  List<Widget> _screens;
  GlobalKey<ScaffoldMessengerState> _scaffoldKey = GlobalKey();
  bool _canExit = GetPlatform.isWeb ? true : false;

  @override
  void initState() {
    super.initState();

    _pageIndex = widget.pageIndex;

    _pageController = PageController(initialPage: widget.pageIndex);

    _screens = [
      HomeScreen(),
      FavouriteScreen(),
      CartScreen(fromNav: true),
      OrderScreen(),
      Container(),
    ];

    Future.delayed(Duration(seconds: 1), () {
      setState(() {});
    });

    /*if(GetPlatform.isMobile) {
      NetworkInfo.checkConnectivity(_scaffoldKey.currentContext);
    }*/
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        if (_pageIndex != 0) {
          _setPage(0);
          return false;
        } else {
          if(!ResponsiveHelper.isDesktop(context) && Get.find<SplashController>().module != null) {
            Get.find<SplashController>().setModule(null);
            return false;
          }else {
            if(_canExit) {
              return true;
            }else {
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                content: Text('back_press_again_to_exit'.tr, style: TextStyle(color: Colors.white)),
                behavior: SnackBarBehavior.floating,
                backgroundColor: Colors.green,
                duration: Duration(seconds: 2),
                margin: EdgeInsets.all(Dimensions.PADDING_SIZE_SMALL),
              ));
              _canExit = true;
              Timer(Duration(seconds: 2), () {
                _canExit = false;
              });
              return false;
            }
          }
        }
      },
      child: Scaffold(
        key: _scaffoldKey,



        body: PersistentTabView(

          context,
          screens: [
            HomeScreen(),
            FavouriteScreen(),
            CartScreen(fromNav: true),
            OrderScreen(),
            Container()
          ],
          items: [
            PersistentBottomNavBarItem(
                icon: Icon(CupertinoIcons.home),
                title: "Home" ,
              activeColorPrimary: Theme.of(context).primaryColor,
              inactiveColorPrimary: CupertinoColors.inactiveGray,

            ),
            PersistentBottomNavBarItem(
              icon: Icon(CupertinoIcons.square_favorites_alt_fill),
              title: "Favourite" ,
              activeColorPrimary: Theme.of(context).primaryColor,
              inactiveColorPrimary: CupertinoColors.inactiveGray,

            ),
            PersistentBottomNavBarItem(
              icon: Icon(CupertinoIcons.cart),
              title: "Cart" ,
              activeColorPrimary: Theme.of(context).primaryColor,
              inactiveColorPrimary: CupertinoColors.inactiveGray,

            ),
            PersistentBottomNavBarItem(
              icon: Icon(CupertinoIcons.bag),
              title: "Orders" ,
              activeColorPrimary: Theme.of(context).primaryColor,
              inactiveColorPrimary: CupertinoColors.inactiveGray,

            ),
            PersistentBottomNavBarItem(
              icon: Icon(CupertinoIcons.list_bullet),
              title: "Menu" ,
              activeColorPrimary: Theme.of(context).primaryColor,
              inactiveColorPrimary: CupertinoColors.inactiveGray,
              onPressed: (value){
                Get.bottomSheet(MenuScreen(), backgroundColor: Colors.transparent, isScrollControlled: true);
              }
            )
          ],
          navBarStyle:NavBarStyle.style3 ,
        )
      ),
    );
  }

  void _setPage(int pageIndex) {
    setState(() {
      _pageController.jumpToPage(pageIndex);
      _pageIndex = pageIndex;
    });
  }
}
