import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:apex_mart/controller/store_controller.dart';
import 'package:apex_mart/util/dimensions.dart';
import 'package:apex_mart/util/styles.dart';

class FilterView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return GetBuilder<StoreController>(builder: (storeController) {
      return storeController.storeModel != null ? PopupMenuButton(
        itemBuilder: (context) {
          return [
            PopupMenuItem(value: 'all', child: Text('all'.tr), textStyle: poppinsMedium.copyWith(
              color: storeController.storeType == 'all'
                  ? Theme.of(context).textTheme.bodyText1.color : Theme.of(context).disabledColor,
            )),
            PopupMenuItem(value: 'take_away', child: Text('take_away'.tr), textStyle: poppinsMedium.copyWith(
              color: storeController.storeType == 'take_away'
                  ? Theme.of(context).textTheme.bodyText1.color : Theme.of(context).disabledColor,
            )),
            PopupMenuItem(value: 'delivery', child: Text('delivery'.tr), textStyle: poppinsMedium.copyWith(
              color: storeController.storeType == 'delivery'
                  ? Theme.of(context).textTheme.bodyText1.color : Theme.of(context).disabledColor,
            )),
          ];
        },
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(Dimensions.RADIUS_SMALL)),
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: Dimensions.PADDING_SIZE_SMALL),
          child: Icon(Icons.menu),
        ),
        onSelected: (value) => storeController.setStoreType(value),
      ) : SizedBox();
    });
  }
}
