import 'package:flutter/material.dart';

ThemeData light({Color color = const Color(0xFFFF9000)}) => ThemeData(
  fontFamily: 'Poppins',
  primaryColor: color,
  secondaryHeaderColor: Color(0xFF2E2E2E),
  disabledColor: Color(0xFFBABFC4),
  backgroundColor: Color(0xFFFFF3E0),
  errorColor: Color(0xFFE84D4F),
  brightness: Brightness.light,
  hintColor: Color(0xFF9F9F9F),
  cardColor: Colors.white,
  canvasColor: Color(0xffFFF9F3),//menu color
  colorScheme: ColorScheme.light(primary: color, secondary: color),
  textButtonTheme: TextButtonThemeData(style: TextButton.styleFrom(primary: color)),
);