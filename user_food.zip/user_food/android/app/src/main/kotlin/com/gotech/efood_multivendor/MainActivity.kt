package com.apex_mart_user

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
